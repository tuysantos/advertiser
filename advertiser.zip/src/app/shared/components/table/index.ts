export * from './table.component';
export * from './table.module';
