export const DIALOG_WIDTHS = {
  small: '500px',
  medium: '800px',
  large: '1000px',
};

export const DIALOG_HEIGHTS = {
  small: '250px',
  medium: '400px',
  large: '600px',
};
