export interface AddressModel {
  id?: number;
  address: string;
  city: string;
  postcode: string;
  updatedTs?: string;
}
