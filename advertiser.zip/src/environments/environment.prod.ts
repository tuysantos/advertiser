export const environment = {
  production: true,
  apiBaseUrl: 'https://arkham.cvtr.io/test/api',
};
