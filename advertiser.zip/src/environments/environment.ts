export const environment = {
  production: false,
  apiBaseUrl: 'https://arkham.cvtr.io/test/api',
};
